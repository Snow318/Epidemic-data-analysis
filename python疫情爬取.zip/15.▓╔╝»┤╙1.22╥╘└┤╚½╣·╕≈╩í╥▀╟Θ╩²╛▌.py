import requests
from bs4 import BeautifulSoup
import re
import json
from tqdm import tqdm
import pandas as pd

class CoronaVirusSpider(object):
    def __init__(self):
        self.home_url = "https://ncov.dxy.cn/ncovh5/view/pneumonia"

    def get_content_from_url(self, url):
        """
        :param url: 根据url获取响应的字符串数据
        :return: 响应内容的字符串
        """
        # 1.发送请求
        response = requests.get(url)
        # 2.获取首页内容，并用decode解析二进制
        return response.content.decode()

    def parse_home_page(self, home_page):
        """
        解析首页内容，获取解析后的python数据
        :param self:
        :param home_page: 首页的内容
        :return: 解析后的python数据
        """
        # 3.使用BeatifulSoup从疫情首页里获取最近一日世界各国疫情数据
        soup = BeautifulSoup(home_page, 'lxml')
        script = soup.find(id='getListByCountryTypeService2true')
        text = script.string
        print(text)
        # 4.使用正则表达式获取json字符串
        json_str = re.findall(r'\[.+\]', text)[0]
        # 5.将json字符串转化为python字符串
        last_data = json.loads(json_str)
        return last_data

    def save(self, data, path):
        # 6.把python类型的数据，以json格式存入文件
        with open(path, 'w', encoding='utf-8') as fp:
            json.dump(data, fp, ensure_ascii=False)

    def crawl_last_day_corona_virus(self):
        """
        采集最近一天的各国疫情信息
        :param self:
        :return:
        """
#         发送请求，获取首页内容
        home_page = self.get_content_from_url(self.home_url)
#         解析首页内容
        last_day_coronavirus =self.parse_home_page(home_page)
#         保存数据
        self.save(last_day_coronavirus, 'last_corona2.json')

    def crawl_corona_virus_from123(self):
        """
        采集1月23日以来各国疫情数据
        :return:
        """
        # 1.加载各国疫情数据
        with open('last_corona.json', encoding='utf-8') as fp:
            last_day_coronavirus = json.load(fp)
        # print(last_day_coronavirus)
        # 定义列表存储各国从1月23日至今的疫情数据
        coronavius_list = []
        # 2.遍历各国疫情数据, 获取统计的url
        for country in tqdm(last_day_coronavirus, '采集1月23日以来的各国疫情信息'):
            # 3.发送请求, 获取从1月23日到至今的json数据
            statistics_data_url = country["statisticsData"]
            statistics_data_json_str = self.get_content_from_url(statistics_data_url)
            # 4.把json数据转换为python类型的数据, 并添加到列表中
            statistics_data = json.loads(statistics_data_json_str)['data']
            # print(statistics_data)
            # 给每一个字典里面填上这个国家的名称
            for one_day in statistics_data:
                one_day['provinceName'] = country['provinceName']
                one_day['countryShortCode'] = country['countryShortCode']
            # print(statistics_data)
            # 把数据元素放到列表里面
        coronavius_list.extend(statistics_data)
        # 5.把列表以json格式存在一个文件里
        self.save(coronavius_list, '123.json')

    def crawl_last_day_corona_virus_of_china(self):
        """
        采集最近一日各省疫情数据
        :return:
        """
    #     1.发送请求获取疫情首页
        home_page = self.get_content_from_url(self.home_url)
    #     2.解析疫情首页，获取最近一日各省疫情数据
        # 3.使用BeatifulSoup从疫情首页里获取最近一日世界各国疫情数据
        soup = BeautifulSoup(home_page, 'lxml')
        script = soup.find(id='getAreaStat')
        text = script.string
        print(text)
        # 4.使用正则表达式获取json字符串
        json_str = re.findall(r'\[.+\]', text)[0]
        # 5.将json字符串转化为python字符串
        last_data = json.loads(json_str)
    #     3.保存疫情数据
        self.save(last_data, "last_day_corona_virus_of_china.json")

    def crawl_corona_virus_of_china(self):
        """
        采集从1.22以来的全国各省的疫情数据
        :return:
        """
    #     1.加载最近一日全国疫情信息
        with open("last_day_corona_virus_of_china.json", encoding='utf-8') as fp:
            last_day_corona_virus_of_china = json.load(fp)
    #     2.遍历最近一日全国疫情信息，获取各省疫情url
        # 定义列表存储各省从1月22日至今的疫情数据
        coronavius_list = []
        # 2.遍历全国各省疫情数据, 获取统计的url
        for province in tqdm(last_day_corona_virus_of_china, '采集1月22日以来全国各省的疫情数据'):
            # 3.发送请求, 获取从各省1月22日到至今的json数据
            statistics_data_url = province["statisticsData"]
            statistics_data_json_str = self.get_content_from_url(statistics_data_url)
            # 4.把json数据转换为python类型的数据, 并添加到列表中
            statistics_data = json.loads(statistics_data_json_str)['data']
            # print(statistics_data)
            # 给每一个字典里面填上这个国家的名称
            for one_day in statistics_data:
                one_day['provinceName'] = province['provinceName']

            # print(statistics_data)
            # 把数据元素放到列表里面
            coronavius_list.extend(statistics_data)
            # print(coronavius_list)

    #     5.以json格式保存疫情信息
            self.save(coronavius_list, "corona_virus_province_of_china.json")
            col_name = ['confirmedCount', 'confirmedIncr', 'curedCount', 'curedIncr', 'currentConfirmedCount', 'currentConfirmedIncr', 'dateId', 'deadCount',
             'suspectedCount', 'suspectedCountIncr', 'provinceName',
                        ]
            df = pd.DataFrame(columns=col_name, data=coronavius_list)
            df.to_csv("corona_virus_province_of_china.csv",encoding='utf-8', index=False)

    def run(self):
        # self.crawl_last_day_corona_virus()
        # self.crawl_corona_virus_from123()
        self.crawl_last_day_corona_virus_of_china()


        self.crawl_corona_virus_of_china()

if __name__ == '__main__':
    requests.adapters.DEFAULT_RETRIES = 5

    spider = CoronaVirusSpider()
    spider.run()






